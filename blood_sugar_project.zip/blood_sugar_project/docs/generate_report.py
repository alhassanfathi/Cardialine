"""
Generate the technical report PDF using ReportLab.
Run from the project root: python docs/generate_report.py
"""

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, KeepTogether
)
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY

OUTPUT = "docs/technical_report.pdf"

W, H = A4
MARGIN = 2.2 * cm

styles = getSampleStyleSheet()

# Custom styles
title_style = ParagraphStyle("Title2", parent=styles["Title"],
    fontSize=20, spaceAfter=6, textColor=colors.HexColor("#1a1a2e"),
    alignment=TA_CENTER)

subtitle_style = ParagraphStyle("Subtitle", parent=styles["Normal"],
    fontSize=11, spaceAfter=16, textColor=colors.HexColor("#555555"),
    alignment=TA_CENTER)

h1_style = ParagraphStyle("H1", parent=styles["Heading1"],
    fontSize=13, spaceBefore=14, spaceAfter=6,
    textColor=colors.HexColor("#1a1a2e"), borderPad=0)

h2_style = ParagraphStyle("H2", parent=styles["Heading2"],
    fontSize=11, spaceBefore=10, spaceAfter=4,
    textColor=colors.HexColor("#333366"))

body_style = ParagraphStyle("Body2", parent=styles["Normal"],
    fontSize=10, leading=15, spaceAfter=6, alignment=TA_JUSTIFY)

code_style = ParagraphStyle("Code", parent=styles["Code"],
    fontSize=8.5, leading=13, backColor=colors.HexColor("#f4f4f4"),
    borderColor=colors.HexColor("#cccccc"), borderWidth=0.5,
    borderPad=6, spaceAfter=8)

disclaimer_style = ParagraphStyle("Disclaimer", parent=styles["Normal"],
    fontSize=8, textColor=colors.grey, alignment=TA_CENTER, spaceAfter=4)


def HR():
    return HRFlowable(width="100%", thickness=0.5,
                      color=colors.HexColor("#cccccc"), spaceAfter=8, spaceBefore=4)


def build_report():
    doc = SimpleDocTemplate(
        OUTPUT,
        pagesize=A4,
        leftMargin=MARGIN, rightMargin=MARGIN,
        topMargin=MARGIN, bottomMargin=MARGIN,
        title="Technical Report – Blood Sugar Analyser",
        author="Health Informatics Group",
    )

    story = []

    # ── Title block ───────────────────────────────────────────────────────────
    story.append(Spacer(1, 0.5 * cm))
    story.append(Paragraph("Blood Sugar Analyser", title_style))
    story.append(Paragraph("Technical Report &ndash; Foundations of Health Informatics",
                            subtitle_style))
    story.append(HR())
    story.append(Paragraph(
        "<i>Educational model only. Not for real clinical decisions.</i>",
        disclaimer_style))
    story.append(Spacer(1, 0.4 * cm))

    # ── 1. Overview ───────────────────────────────────────────────────────────
    story.append(Paragraph("1. Project Overview", h1_style))
    story.append(Paragraph(
        "This programme reads blood glucose measurements from a CSV file, classifies "
        "each reading against established clinical thresholds, computes per-patient "
        "summary statistics, detects anomalous values using two complementary methods, "
        "and produces a multi-panel visualisation. It was developed as part of the "
        "Foundations of Health Informatics course and serves as an educational "
        "demonstration of data processing pipelines in a healthcare context.",
        body_style))

    # ── 2. Architecture ───────────────────────────────────────────────────────
    story.append(Paragraph("2. Architecture and Module Design", h1_style))
    story.append(Paragraph(
        "The codebase follows a strict separation of concerns, dividing responsibility "
        "across five dedicated modules. Each module has a single, well-defined role:",
        body_style))

    module_data = [
        ["Module", "Responsibility"],
        ["src/loader.py",     "CSV I/O and schema validation"],
        ["src/classifier.py", "Clinical threshold classification of individual readings"],
        ["src/analyser.py",   "Per-patient metrics and anomaly detection pipeline"],
        ["src/plotter.py",    "Matplotlib multi-panel visualisation"],
        ["src/reporter.py",   "Formatted console output"],
        ["main.py",           "Entry point; orchestrates the pipeline"],
    ]
    t = Table(module_data, colWidths=[4.5 * cm, 11 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND",   (0, 0), (-1, 0), colors.HexColor("#1a1a2e")),
        ("TEXTCOLOR",    (0, 0), (-1, 0), colors.white),
        ("FONTNAME",     (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",     (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.HexColor("#f9f9f9"), colors.white]),
        ("GRID",         (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
        ("PADDING",      (0, 0), (-1, -1), 5),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.3 * cm))

    story.append(Paragraph(
        "This design makes each component independently testable and replaceable. "
        "For example, the output format can be changed by modifying only reporter.py, "
        "without touching the analysis logic.",
        body_style))

    # ── 3. Data Structures ────────────────────────────────────────────────────
    story.append(Paragraph("3. Data Structures", h1_style))

    story.append(Paragraph("3.1 Input Data", h2_style))
    story.append(Paragraph(
        "All data is loaded into a pandas DataFrame with the following columns: "
        "patient_id (string), timestamp (datetime64), blood_sugar_mg_dl (float64), "
        "measurement_type (string: fasting / pre_meal / post_meal), and notes (string). "
        "A status column (string) is added by the classifier.",
        body_style))

    story.append(Paragraph("3.2 Thresholds", h2_style))
    story.append(Paragraph(
        "Clinical thresholds are encapsulated in a frozen Python dataclass "
        "(Thresholds in classifier.py). Using a dataclass with frozen=True makes "
        "the configuration immutable and easily substitutable in tests, where "
        "custom thresholds can be passed without modifying global state.",
        body_style))

    story.append(Paragraph(
        "Example: <font name='Courier'>Thresholds(hypo_warning=80.0)</font> "
        "overrides only the hypoglycaemia threshold while keeping all others at "
        "standard values. This pattern was chosen over global constants to support "
        "testability and future configurability.",
        body_style))

    # ── 4. Core Algorithms ────────────────────────────────────────────────────
    story.append(Paragraph("4. Core Algorithms", h1_style))

    story.append(Paragraph("4.1 Classification Logic", h2_style))
    story.append(Paragraph(
        "The classify_reading() function in classifier.py applies a priority-ordered "
        "decision tree. Critical values (hypoglycaemia below 60 mg/dL, "
        "hyperglycaemia above 300 mg/dL) are evaluated first, before measurement-type "
        "specific thresholds. This mirrors clinical triage logic, where life-threatening "
        "values must be identified regardless of context. "
        "Fasting and pre-meal readings use tighter thresholds (normal: 70-99 mg/dL) "
        "than post-meal readings (normal: below 140 mg/dL), as recommended by standard "
        "diabetes care guidelines.",
        body_style))

    story.append(Paragraph("4.2 Dual Anomaly Detection", h2_style))
    story.append(Paragraph(
        "Anomaly detection in find_anomalies() (analyser.py) uses two strategies "
        "in combination:",
        body_style))
    story.append(Paragraph(
        "<b>Clinical flagging:</b> Any reading classified as LOW, HIGH, CRITICAL_LOW, "
        "or CRITICAL_HIGH is flagged. This catches absolute threshold violations.",
        body_style))
    story.append(Paragraph(
        "<b>Statistical outlier detection:</b> Readings more than 2 standard deviations "
        "from the patient's own mean are additionally flagged (z-score method). "
        "This catches relative anomalies that may not breach absolute thresholds — "
        "for example, an unusually high reading for a patient whose values are "
        "consistently low-normal.",
        body_style))
    story.append(Paragraph(
        "Combining both methods reduces both false negatives (missed anomalies) "
        "and false positives (unnecessary alerts).",
        body_style))

    # ── 5. LLM Use ────────────────────────────────────────────────────────────
    story.append(Paragraph("5. LLM Use and Reflection", h1_style))

    llm_data = [
        ["Task", "LLM Used?", "Adaptation"],
        ["Sample CSV data generation",    "Yes", "Values and patient profiles reviewed for clinical realism"],
        ["Clinical threshold values",     "Yes (suggested)", "Cross-checked against ADA guidelines; used as-is"],
        ["Dual anomaly detection idea",   "Yes (suggested)", "Implemented independently; z-score threshold set to 2.0 after testing"],
        ["Matplotlib plot layout",        "Yes", "Panel arrangement adapted; colour scheme replaced with accessible palette"],
        ["Module separation / design",    "No",  "Architecture designed by authors; LLM used only for review"],
        ["Unit test cases",               "Partial", "Edge cases (custom thresholds, empty DataFrames) added by authors"],
        ["ReportLab PDF structure",       "No",  "Written from scratch using official ReportLab documentation"],
    ]
    t2 = Table(llm_data, colWidths=[5.5 * cm, 2.5 * cm, 7.5 * cm])
    t2.setStyle(TableStyle([
        ("BACKGROUND",   (0, 0), (-1, 0), colors.HexColor("#333366")),
        ("TEXTCOLOR",    (0, 0), (-1, 0), colors.white),
        ("FONTNAME",     (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",     (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1),
         [colors.HexColor("#f9f9f9"), colors.white]),
        ("GRID",         (0, 0), (-1, -1), 0.4, colors.HexColor("#dddddd")),
        ("PADDING",      (0, 0), (-1, -1), 5),
        ("VALIGN",       (0, 0), (-1, -1), "TOP"),
        ("WORDWRAP",     (0, 0), (-1, -1), True),
    ]))
    story.append(t2)
    story.append(Spacer(1, 0.3 * cm))
    story.append(Paragraph(
        "The LLM was most valuable for rapidly generating realistic test data and "
        "suggesting the dual anomaly detection approach. The critical design decisions "
        "— module boundaries, the frozen dataclass for thresholds, and test case "
        "structure — were made by the authors. In all cases, LLM output was treated "
        "as a starting point for review and adaptation, not as a final answer.",
        body_style))

    # ── 6. Design Decisions ───────────────────────────────────────────────────
    story.append(Paragraph("6. Key Design Decisions", h1_style))

    decisions = [
        ("Frozen dataclass for thresholds",
         "Ensures immutability (no accidental mutation), enables easy test "
         "overrides, and makes configuration explicit rather than scattered "
         "across the codebase as magic numbers."),
        ("apply_classifications() returns a copy",
         "The original DataFrame is never mutated. This avoids subtle bugs "
         "from shared state and makes the function safe to call multiple times."),
        ("Modality-aware classification",
         "Using different thresholds for fasting vs post-meal readings reflects "
         "real clinical practice. A reading of 130 mg/dL is high when fasting "
         "but normal after a meal."),
        ("Z-score per patient (not global)",
         "Statistical outlier detection is computed per patient, not across all "
         "patients. This is important because a diabetic patient's baseline "
         "values are much higher than a healthy patient's — a global z-score "
         "would produce misleading results."),
    ]
    for title, detail in decisions:
        story.append(Paragraph(f"<b>{title}:</b> {detail}", body_style))

    # ── Footer ────────────────────────────────────────────────────────────────
    story.append(Spacer(1, 0.5 * cm))
    story.append(HR())
    story.append(Paragraph(
        "Educational model only. Not for real clinical decisions. "
        "Foundations of Health Informatics — University Project.",
        disclaimer_style))

    doc.build(story)
    print(f"[INFO] Technical report saved to: {OUTPUT}")


if __name__ == "__main__":
    build_report()
