# Blood Sugar Analyser

> **Educational model only — not for real clinical decisions.**

A Python programme that reads blood glucose readings from a CSV file, classifies them against clinical thresholds, calculates key metrics per patient, detects anomalous values, and produces a multi-panel summary plot.

---

## Features

- Loads and validates CSV files with blood sugar readings
- Classifies each reading: `NORMAL` / `ELEVATED` / `HIGH` / `LOW` / `CRITICAL_LOW` / `CRITICAL_HIGH`
- Computes per-patient statistics: mean, median, standard deviation, min/max, % in each category
- Detects anomalies using **two methods**: clinical thresholds + statistical outlier detection (z-score)
- Generates a 3-panel PNG report: time series, box plot, status breakdown
- Prints a formatted console report

---

## Project Structure

```
blood_sugar_project/
├── main.py                  # Entry point
├── src/
│   ├── loader.py            # CSV loading and validation
│   ├── classifier.py        # Clinical threshold classification
│   ├── analyser.py          # Metrics + anomaly detection
│   ├── plotter.py           # Matplotlib visualisation
│   └── reporter.py          # Console report output
├── tests/
│   ├── test_classifier.py   # Unit tests for classification logic
│   ├── test_analyser.py     # Unit tests for metrics and anomaly detection
│   └── test_loader.py       # Unit tests for CSV loading
├── data/
│   └── blood_sugar.csv      # Sample data (54 readings, 3 patients)
├── docs/
│   └── blood_sugar_report.png  # Generated plot (after first run)
└── README.md
```

---

## Installation

**Requirements:** Python 3.10+

Install dependencies:

```bash
pip install pandas numpy matplotlib reportlab
```

No additional setup required.

---

## Usage

### Run with default sample data

```bash
python main.py
```

### Run with a custom CSV file

```bash
python main.py path/to/your_data.csv path/to/output_plot.png
```

### Run unit tests

```bash
python -m pytest tests/ -v
```

### Check test coverage

```bash
python -m pytest tests/ --cov=src --cov-report=term-missing
```

---

## CSV Format

The input CSV must contain these columns:

| Column | Type | Description |
|---|---|---|
| `patient_id` | string | Patient identifier (e.g. `P001`) |
| `timestamp` | datetime | Date and time of measurement (e.g. `2024-01-15 07:30`) |
| `blood_sugar_mg_dl` | float | Blood glucose reading in mg/dL |
| `measurement_type` | string | Optional: `fasting`, `pre_meal`, `post_meal` |
| `notes` | string | Optional: free-text notes |

Example:

```csv
patient_id,timestamp,blood_sugar_mg_dl,measurement_type,notes
P001,2024-01-15 07:30,95,fasting,morning reading
P001,2024-01-15 09:30,145,post_meal,after breakfast
```

---

## Clinical Reference Ranges

| Condition | Fasting (mg/dL) | Post-meal (mg/dL) |
|---|---|---|
| Normal | 70–99 | < 140 |
| Pre-diabetic | 100–125 | 140–199 |
| Diabetic | ≥ 126 | ≥ 200 |
| Hypoglycaemia warning | < 70 | < 70 |
| Critical hypoglycaemia | < 60 | < 60 |
| Critical hyperglycaemia | > 300 | > 300 |

---

## LLM Usage

LLMs (Claude) were used to:
- Generate realistic sample CSV data covering normal, pre-diabetic, and diabetic patient profiles
- Suggest the dual anomaly detection approach (clinical + statistical)
- Assist with matplotlib plot structure

All classification logic, module design, and test cases were written and reviewed by the authors. See `docs/technical_report.pdf` for full details.

---

## Disclaimer

This is an **educational project** for a university course in Health Informatics. It must not be used for real medical decisions. Always consult a qualified healthcare professional.
