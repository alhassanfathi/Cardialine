"""
test_analyser.py
----------------
Unit tests for data classification, metrics computation, and anomaly detection.
"""

import pytest
import pandas as pd
import numpy as np
from src.analyser import apply_classifications, compute_metrics, find_anomalies


def make_df(records):
    """Helper: build a minimal DataFrame from a list of dicts."""
    return pd.DataFrame(records)


class TestApplyClassifications:
    def test_adds_status_column(self):
        df = make_df([
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01"),
             "blood_sugar_mg_dl": 90.0, "measurement_type": "fasting"},
        ])
        result = apply_classifications(df)
        assert "status" in result.columns

    def test_normal_classified_correctly(self):
        df = make_df([
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01"),
             "blood_sugar_mg_dl": 90.0, "measurement_type": "fasting"},
        ])
        result = apply_classifications(df)
        assert result.iloc[0]["status"] == "NORMAL"

    def test_does_not_mutate_original(self):
        df = make_df([
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01"),
             "blood_sugar_mg_dl": 90.0, "measurement_type": "fasting"},
        ])
        apply_classifications(df)
        assert "status" not in df.columns

    def test_missing_measurement_type_column(self):
        df = make_df([
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01"),
             "blood_sugar_mg_dl": 120.0},
        ])
        result = apply_classifications(df)
        assert result.iloc[0]["status"] == "NORMAL"  # 120 post-meal = normal


class TestComputeMetrics:
    def _classified_df(self):
        df = make_df([
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01 08:00"),
             "blood_sugar_mg_dl": 80.0,  "measurement_type": "fasting"},
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01 10:00"),
             "blood_sugar_mg_dl": 150.0, "measurement_type": "post_meal"},
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01 14:00"),
             "blood_sugar_mg_dl": 210.0, "measurement_type": "post_meal"},
        ])
        return apply_classifications(df)

    def test_returns_one_row_per_patient(self):
        df = self._classified_df()
        metrics = compute_metrics(df)
        assert len(metrics) == 1

    def test_mean_is_correct(self):
        df = self._classified_df()
        metrics = compute_metrics(df)
        expected = round((80 + 150 + 210) / 3, 1)
        assert metrics.iloc[0]["mean_mg_dl"] == expected

    def test_min_max_correct(self):
        df = self._classified_df()
        metrics = compute_metrics(df)
        assert metrics.iloc[0]["min_mg_dl"] == 80
        assert metrics.iloc[0]["max_mg_dl"] == 210

    def test_abnormal_count(self):
        df = self._classified_df()
        metrics = compute_metrics(df)
        # 210 post-meal = HIGH → 1 abnormal
        assert metrics.iloc[0]["abnormal_count"] == 1

    def test_multiple_patients(self):
        df = make_df([
            {"patient_id": "P1", "timestamp": pd.Timestamp("2024-01-01"),
             "blood_sugar_mg_dl": 90.0, "measurement_type": "fasting"},
            {"patient_id": "P2", "timestamp": pd.Timestamp("2024-01-01"),
             "blood_sugar_mg_dl": 200.0, "measurement_type": "post_meal"},
        ])
        df = apply_classifications(df)
        metrics = compute_metrics(df)
        assert len(metrics) == 2


class TestFindAnomalies:
    def _make_patient_df(self, values, mtype="post_meal"):
        records = [
            {"patient_id": "P1",
             "timestamp": pd.Timestamp(f"2024-01-0{i+1}"),
             "blood_sugar_mg_dl": v,
             "measurement_type": mtype,
             "notes": ""}
            for i, v in enumerate(values)
        ]
        df = pd.DataFrame(records)
        return apply_classifications(df)

    def test_critical_low_detected(self):
        df = self._make_patient_df([90, 95, 88, 55, 92])
        anomalies = find_anomalies(df)
        assert 55 in anomalies["value_mg_dl"].values

    def test_critical_high_detected(self):
        df = self._make_patient_df([120, 130, 315, 125, 118])
        anomalies = find_anomalies(df)
        assert 315 in anomalies["value_mg_dl"].values

    def test_no_anomalies_returns_empty_df(self):
        df = self._make_patient_df([100, 105, 98, 102, 99])
        anomalies = find_anomalies(df)
        assert anomalies.empty

    def test_statistical_outlier_detected(self):
        # All values normal clinically, but one is a statistical outlier
        values = [100, 102, 98, 101, 99, 103, 97, 100, 99, 155]
        df = self._make_patient_df(values, mtype="fasting")
        anomalies = find_anomalies(df)
        reasons = " ".join(anomalies["reasons"].tolist())
        assert "Statistical outlier" in reasons

    def test_returns_correct_columns(self):
        df = self._make_patient_df([55, 100, 105])
        anomalies = find_anomalies(df)
        expected_cols = {"patient_id", "timestamp", "value_mg_dl",
                         "type", "status", "reasons", "notes"}
        assert expected_cols.issubset(set(anomalies.columns))
