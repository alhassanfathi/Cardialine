"""
test_loader.py
--------------
Unit tests for CSV loading and validation logic.
"""

import pytest
import pandas as pd
import os
import tempfile
from src.loader import load_csv


def write_csv(content: str) -> str:
    """Helper: write CSV content to a temp file and return its path."""
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False)
    f.write(content)
    f.close()
    return f.name


class TestLoadCsv:
    def test_loads_valid_csv(self):
        path = write_csv(
            "patient_id,timestamp,blood_sugar_mg_dl,measurement_type,notes\n"
            "P1,2024-01-01 08:00,95,fasting,\n"
        )
        df = load_csv(path)
        assert len(df) == 1
        assert df.iloc[0]["patient_id"] == "P1"
        os.unlink(path)

    def test_parses_timestamp_as_datetime(self):
        path = write_csv(
            "patient_id,timestamp,blood_sugar_mg_dl\n"
            "P1,2024-01-15 07:30,95\n"
        )
        df = load_csv(path)
        assert pd.api.types.is_datetime64_any_dtype(df["timestamp"])
        os.unlink(path)

    def test_drops_rows_with_missing_blood_sugar(self):
        path = write_csv(
            "patient_id,timestamp,blood_sugar_mg_dl\n"
            "P1,2024-01-01,95\n"
            "P1,2024-01-02,\n"
        )
        df = load_csv(path)
        assert len(df) == 1
        os.unlink(path)

    def test_drops_rows_with_non_numeric_blood_sugar(self):
        path = write_csv(
            "patient_id,timestamp,blood_sugar_mg_dl\n"
            "P1,2024-01-01,95\n"
            "P1,2024-01-02,abc\n"
        )
        df = load_csv(path)
        assert len(df) == 1
        os.unlink(path)

    def test_sorted_by_patient_and_time(self):
        path = write_csv(
            "patient_id,timestamp,blood_sugar_mg_dl\n"
            "P2,2024-01-01,100\n"
            "P1,2024-01-02,90\n"
            "P1,2024-01-01,80\n"
        )
        df = load_csv(path)
        assert list(df["patient_id"]) == ["P1", "P1", "P2"]
        os.unlink(path)

    def test_exits_on_missing_file(self):
        with pytest.raises(SystemExit):
            load_csv("nonexistent_file.csv")

    def test_exits_on_missing_required_columns(self):
        path = write_csv("name,value\nA,1\n")
        with pytest.raises(SystemExit):
            load_csv(path)
        os.unlink(path)
