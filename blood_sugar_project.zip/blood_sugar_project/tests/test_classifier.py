"""
test_classifier.py
------------------
Unit tests for the blood sugar classification logic.
Covers all status categories and edge cases.
"""

import pytest
from src.classifier import (
    classify_reading,
    Thresholds,
    STATUS_CRITICAL_LOW,
    STATUS_LOW,
    STATUS_NORMAL,
    STATUS_ELEVATED,
    STATUS_HIGH,
    STATUS_CRITICAL_HIGH,
)

T = Thresholds()  # default thresholds


class TestCriticalLow:
    def test_below_critical_threshold(self):
        assert classify_reading(55.0, "fasting") == STATUS_CRITICAL_LOW

    def test_exactly_at_critical_threshold(self):
        # Value exactly at hypo_critical (60) is still CRITICAL_LOW (< 60 is False)
        assert classify_reading(59.9, "fasting") == STATUS_CRITICAL_LOW

    def test_critical_low_post_meal(self):
        assert classify_reading(45.0, "post_meal") == STATUS_CRITICAL_LOW


class TestLow:
    def test_between_hypo_warning_and_critical(self):
        assert classify_reading(65.0, "fasting") == STATUS_LOW

    def test_exactly_at_hypo_warning_minus_one(self):
        assert classify_reading(69.9, "post_meal") == STATUS_LOW


class TestCriticalHigh:
    def test_above_critical_high(self):
        assert classify_reading(310.0, "post_meal") == STATUS_CRITICAL_HIGH

    def test_exactly_at_critical_high_plus_one(self):
        assert classify_reading(300.1, "fasting") == STATUS_CRITICAL_HIGH


class TestFastingClassification:
    def test_normal_fasting(self):
        assert classify_reading(85.0, "fasting") == STATUS_NORMAL

    def test_upper_normal_fasting(self):
        assert classify_reading(99.0, "fasting") == STATUS_NORMAL

    def test_pre_diabetic_fasting(self):
        assert classify_reading(112.0, "fasting") == STATUS_ELEVATED

    def test_upper_pre_diabetic_fasting(self):
        assert classify_reading(125.0, "fasting") == STATUS_ELEVATED

    def test_diabetic_fasting(self):
        assert classify_reading(130.0, "fasting") == STATUS_HIGH

    def test_pre_meal_treated_as_fasting(self):
        assert classify_reading(90.0, "pre_meal") == STATUS_NORMAL


class TestPostMealClassification:
    def test_normal_post_meal(self):
        assert classify_reading(120.0, "post_meal") == STATUS_NORMAL

    def test_elevated_post_meal(self):
        assert classify_reading(165.0, "post_meal") == STATUS_ELEVATED

    def test_high_post_meal(self):
        assert classify_reading(210.0, "post_meal") == STATUS_HIGH

    def test_unknown_type_treated_as_post_meal(self):
        # Unknown measurement type defaults to post-meal thresholds
        assert classify_reading(120.0, "") == STATUS_NORMAL
        assert classify_reading(210.0, "") == STATUS_HIGH


class TestCustomThresholds:
    def test_custom_thresholds_respected(self):
        custom = Thresholds(hypo_warning=80.0)
        assert classify_reading(75.0, "fasting", custom) == STATUS_LOW
        assert classify_reading(75.0, "fasting", T) == STATUS_NORMAL
