"""
plotter.py
----------
Generates a multi-panel summary plot of blood sugar analysis results.

Panels:
  1. Time-series line chart per patient with threshold reference lines
  2. Box plot showing value distribution per patient
  3. Stacked bar chart of status breakdown per patient
"""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import pandas as pd
from src.classifier import STATUS_COLORS


# Consistent colour palette for patients
PATIENT_PALETTE = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd"]


def _patient_color_map(patients) -> dict:
    return {p: PATIENT_PALETTE[i % len(PATIENT_PALETTE)] for i, p in enumerate(patients)}


def generate_plot(df: pd.DataFrame, output_path: str) -> None:
    """
    Produce and save the 3-panel summary figure.

    Args:
        df:          Classified DataFrame (must have 'status' column).
        output_path: File path to save the PNG image.
    """
    patients = df["patient_id"].unique()
    pat_colors = _patient_color_map(patients)

    fig = plt.figure(figsize=(16, 12), facecolor="#f8f9fa")
    fig.suptitle("Blood Sugar Level Analysis Report",
                 fontsize=18, fontweight="bold", y=0.98, color="#1a1a2e")

    gs = GridSpec(2, 2, figure=fig, hspace=0.45, wspace=0.35,
                  left=0.08, right=0.96, top=0.92, bottom=0.06)

    ax_ts  = fig.add_subplot(gs[0, :])   # time series — full width
    ax_box = fig.add_subplot(gs[1, 0])   # box plot
    ax_bar = fig.add_subplot(gs[1, 1])   # status breakdown

    _plot_time_series(ax_ts, df, patients, pat_colors)
    _plot_boxplot(ax_box, df, patients, pat_colors)
    _plot_status_bars(ax_bar, df)

    fig.text(
        0.5, 0.005,
        "Educational model only — not for clinical use. "
        "Reference: fasting normal 70-99 mg/dL | post-meal normal <140 mg/dL.",
        ha="center", fontsize=8, color="gray", style="italic",
    )

    plt.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"[INFO] Plot saved to: {output_path}")


def _plot_time_series(ax, df, patients, pat_colors):
    """Panel 1: Line chart of readings over time."""
    for pid in patients:
        group = df[df["patient_id"] == pid].sort_values("timestamp")
        ax.plot(group["timestamp"], group["blood_sugar_mg_dl"],
                marker="o", markersize=4, linewidth=1.5,
                label=pid, color=pat_colors[pid])
        # Highlight anomalous points
        anom = group[group["status"].isin(["CRITICAL_LOW", "CRITICAL_HIGH", "LOW", "HIGH"])]
        if not anom.empty:
            ax.scatter(anom["timestamp"], anom["blood_sugar_mg_dl"],
                       s=120, zorder=5, edgecolors="black", linewidths=0.8,
                       color=[STATUS_COLORS[s] for s in anom["status"]])

    # Clinical reference bands and lines
    ax.axhspan(0,   70,  alpha=0.07, color="#d62728")
    ax.axhspan(300, 450, alpha=0.07, color="#d62728")
    for y, label, color in [
        (70,  "Hypo threshold (70)",      "#d62728"),
        (140, "Post-meal limit (140)",     "#ff7f0e"),
        (200, "Diabetic post-meal (200)",  "#d62728"),
    ]:
        ax.axhline(y, color=color, linestyle="--", linewidth=0.9, alpha=0.6)
        ax.text(df["timestamp"].max(), y + 3, label,
                fontsize=7, color="gray", ha="right")

    ax.set_title("Blood Sugar Levels Over Time", fontweight="bold", pad=10)
    ax.set_ylabel("Blood Sugar (mg/dL)")
    ax.set_xlabel("Date / Time")
    ax.legend(loc="upper right", framealpha=0.9)
    ax.tick_params(axis="x", rotation=30)
    ax.set_facecolor("#ffffff")
    ax.grid(True, linestyle=":", alpha=0.4)


def _plot_boxplot(ax, df, patients, pat_colors):
    """Panel 2: Distribution box plot per patient."""
    data = [df[df["patient_id"] == p]["blood_sugar_mg_dl"].values for p in patients]
    bp = ax.boxplot(data, patch_artist=True,
                    medianprops=dict(color="black", linewidth=2))
    for patch, pid in zip(bp["boxes"], patients):
        patch.set_facecolor(pat_colors[pid])
        patch.set_alpha(0.75)

    ax.set_xticklabels(patients, rotation=15)
    ax.axhline(140, color="#ff7f0e", linestyle="--", linewidth=1, alpha=0.7)
    ax.axhline(70,  color="#d62728", linestyle="--", linewidth=1, alpha=0.7)
    ax.set_title("Value Distribution per Patient", fontweight="bold")
    ax.set_ylabel("Blood Sugar (mg/dL)")
    ax.set_facecolor("#ffffff")
    ax.grid(True, axis="y", linestyle=":", alpha=0.4)


def _plot_status_bars(ax, df):
    """Panel 3: Stacked bar chart of status breakdown."""
    status_order = ["CRITICAL_LOW", "LOW", "NORMAL", "ELEVATED", "HIGH", "CRITICAL_HIGH"]
    present = [s for s in status_order if s in df["status"].values]

    counts = (
        df.groupby(["patient_id", "status"])
          .size()
          .unstack(fill_value=0)
          .reindex(columns=present, fill_value=0)
    )
    colors = [STATUS_COLORS[s] for s in counts.columns]
    counts.plot(kind="bar", stacked=True, ax=ax, color=colors,
                edgecolor="white", linewidth=0.5)

    ax.set_title("Reading Status Breakdown", fontweight="bold")
    ax.set_ylabel("Number of Readings")
    ax.set_xlabel("")
    ax.tick_params(axis="x", rotation=15)
    ax.legend(title="Status", fontsize=8, title_fontsize=8,
              loc="upper left", framealpha=0.9)
    ax.set_facecolor("#ffffff")
    ax.grid(True, axis="y", linestyle=":", alpha=0.4)
