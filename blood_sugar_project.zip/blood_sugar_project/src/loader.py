"""
loader.py
---------
Responsible for loading and validating blood sugar CSV data.
Separation of concerns: this module only handles I/O and schema validation.
"""

import sys
import pandas as pd


REQUIRED_COLUMNS = {"patient_id", "timestamp", "blood_sugar_mg_dl"}


def load_csv(filepath: str) -> pd.DataFrame:
    """
    Load a blood sugar CSV file and return a cleaned DataFrame.

    Args:
        filepath: Path to the CSV file.

    Returns:
        Validated and sorted DataFrame.

    Raises:
        SystemExit: If file is missing, unreadable, or missing required columns.
    """
    try:
        df = pd.read_csv(filepath, parse_dates=["timestamp"])
    except FileNotFoundError:
        sys.exit(f"[ERROR] File not found: {filepath}")
    except Exception as exc:
        sys.exit(f"[ERROR] Could not read CSV: {exc}")

    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        sys.exit(f"[ERROR] Missing required columns: {missing}")

    before = len(df)
    df["blood_sugar_mg_dl"] = pd.to_numeric(df["blood_sugar_mg_dl"], errors="coerce")
    df = df.dropna(subset=["blood_sugar_mg_dl"]).copy()
    dropped = before - len(df)
    if dropped:
        print(f"[WARNING] Dropped {dropped} row(s) with invalid blood sugar values.")

    df = df.sort_values(["patient_id", "timestamp"]).reset_index(drop=True)
    return df
