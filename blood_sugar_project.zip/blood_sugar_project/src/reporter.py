"""
reporter.py
-----------
Handles all console output / text reporting.
Cleanly separated from analysis logic so output format can be changed independently.
"""

import pandas as pd
from datetime import datetime


SEP = "=" * 65


def print_report(metrics: pd.DataFrame, anomalies: pd.DataFrame) -> None:
    """
    Print a formatted text report to stdout.

    Args:
        metrics:   Per-patient summary metrics from analyser.compute_metrics().
        anomalies: Anomaly records from analyser.find_anomalies().
    """
    print(SEP)
    print("  BLOOD SUGAR ANALYSIS REPORT")
    print(f"  Generated: {datetime.now().strftime('%d %B %Y %H:%M')}")
    print(SEP)

    for _, row in metrics.iterrows():
        print(f"\n  Patient : {row['patient_id']}  ({row['reading_count']} readings)")
        print(f"  {'Mean':<12} {row['mean_mg_dl']} mg/dL")
        print(f"  {'Median':<12} {row['median_mg_dl']} mg/dL")
        print(f"  {'Std Dev':<12} +/-{row['std_dev']} mg/dL")
        print(f"  {'Range':<12} {row['min_mg_dl']} - {row['max_mg_dl']} mg/dL")
        print(f"  {'Normal':<12} {row['pct_normal']}%   "
              f"Elevated: {row['pct_elevated']}%   "
              f"High: {row['pct_high']}%")
        print(f"  Abnormal readings: {row['abnormal_count']}")

    print(f"\n{SEP}")
    print("  UNUSUAL VALUES DETECTED")
    print(SEP)

    if anomalies.empty:
        print("  No unusual values found.")
    else:
        for _, a in anomalies.iterrows():
            ts = (a["timestamp"].strftime("%d %b %H:%M")
                  if pd.notna(a["timestamp"]) else "?")
            print(f"  {a['patient_id']}  |  {ts}  |  "
                  f"{int(a['value_mg_dl'])} mg/dL  |  {a['status']}")
            print(f"           Reason: {a['reasons']}")
            if pd.notna(a["notes"]) and str(a["notes"]).strip():
                print(f"           Note  : {a['notes']}")

    print(SEP)
