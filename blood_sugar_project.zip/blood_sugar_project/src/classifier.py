"""
classifier.py
-------------
Classifies individual blood sugar readings against clinical thresholds.

Reference ranges (mg/dL) based on standard diabetes care guidelines:
  Hypoglycaemia critical  : < 60
  Hypoglycaemia warning   : < 70
  Fasting normal          : 70–99
  Fasting pre-diabetic    : 100–125
  Fasting diabetic        : >= 126
  Post-meal normal        : < 140
  Post-meal pre-diabetic  : 140–199
  Post-meal diabetic      : >= 200
  Critical hyperglycaemia : > 300

DISCLAIMER: Educational model only. Not for clinical use.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Thresholds:
    """Immutable set of clinical blood sugar thresholds (mg/dL)."""
    hypo_critical: float = 60.0
    hypo_warning: float = 70.0
    fasting_normal_max: float = 99.0
    fasting_pre_max: float = 125.0
    post_normal_max: float = 140.0
    post_pre_max: float = 199.0
    hyper_critical: float = 300.0


# Status labels, ordered from most to least severe
STATUS_CRITICAL_LOW = "CRITICAL_LOW"
STATUS_LOW = "LOW"
STATUS_NORMAL = "NORMAL"
STATUS_ELEVATED = "ELEVATED"
STATUS_HIGH = "HIGH"
STATUS_CRITICAL_HIGH = "CRITICAL_HIGH"

ABNORMAL_STATUSES = {STATUS_CRITICAL_LOW, STATUS_LOW, STATUS_HIGH, STATUS_CRITICAL_HIGH}

STATUS_COLORS = {
    STATUS_CRITICAL_LOW:  "#8B0000",
    STATUS_LOW:           "#ff7f0e",
    STATUS_NORMAL:        "#2ca02c",
    STATUS_ELEVATED:      "#bcbd22",
    STATUS_HIGH:          "#d95f02",
    STATUS_CRITICAL_HIGH: "#d62728",
}

DEFAULT_THRESHOLDS = Thresholds()


def classify_reading(value: float, measurement_type: str,
                     thresholds: Thresholds = DEFAULT_THRESHOLDS) -> str:
    """
    Classify a single blood sugar reading.

    Args:
        value:            Blood sugar level in mg/dL.
        measurement_type: One of 'fasting', 'pre_meal', 'post_meal', or similar.
        thresholds:       Clinical threshold configuration (default: standard values).

    Returns:
        A status string: CRITICAL_LOW | LOW | NORMAL | ELEVATED | HIGH | CRITICAL_HIGH
    """
    if value < thresholds.hypo_critical:
        return STATUS_CRITICAL_LOW

    if value < thresholds.hypo_warning:
        return STATUS_LOW

    if value > thresholds.hyper_critical:
        return STATUS_CRITICAL_HIGH

    mtype = str(measurement_type).lower()
    is_fasting_type = "fasting" in mtype or "pre" in mtype

    if is_fasting_type:
        if value <= thresholds.fasting_normal_max:
            return STATUS_NORMAL
        if value <= thresholds.fasting_pre_max:
            return STATUS_ELEVATED
        return STATUS_HIGH
    else:
        # post-meal or unknown
        if value < thresholds.post_normal_max:
            return STATUS_NORMAL
        if value < thresholds.post_pre_max:
            return STATUS_ELEVATED
        return STATUS_HIGH
