"""
analyser.py
-----------
Computes per-patient metrics and detects anomalous readings.

Two anomaly detection strategies:
  1. Clinical thresholds (LOW / HIGH / CRITICAL) via classifier.py
  2. Statistical outliers: readings beyond mean ± 2 standard deviations per patient
"""

import pandas as pd
import numpy as np
from src.classifier import classify_reading, ABNORMAL_STATUSES


def apply_classifications(df: pd.DataFrame) -> pd.DataFrame:
    """
    Add a 'status' column to the DataFrame by classifying each reading.

    Args:
        df: DataFrame with 'blood_sugar_mg_dl' and optional 'measurement_type'.

    Returns:
        DataFrame with an added 'status' column.
    """
    df = df.copy()
    mtype = df.get("measurement_type", pd.Series([""] * len(df)))
    df["status"] = [
        classify_reading(val, mt)
        for val, mt in zip(df["blood_sugar_mg_dl"], mtype.fillna(""))
    ]
    return df


def compute_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """
    Calculate summary statistics per patient.

    Args:
        df: Classified DataFrame (must have 'status' column).

    Returns:
        DataFrame with one row per patient containing key metrics.
    """
    rows = []
    for patient_id, group in df.groupby("patient_id"):
        values = group["blood_sugar_mg_dl"]
        rows.append({
            "patient_id":      patient_id,
            "reading_count":   len(values),
            "mean_mg_dl":      round(float(values.mean()), 1),
            "median_mg_dl":    round(float(values.median()), 1),
            "std_dev":         round(float(values.std()), 1),
            "min_mg_dl":       int(values.min()),
            "max_mg_dl":       int(values.max()),
            "pct_normal":      round((group["status"] == "NORMAL").mean() * 100, 1),
            "pct_elevated":    round((group["status"] == "ELEVATED").mean() * 100, 1),
            "pct_high":        round((group["status"] == "HIGH").mean() * 100, 1),
            "abnormal_count":  int(group["status"].isin(ABNORMAL_STATUSES).sum()),
        })
    return pd.DataFrame(rows)


def find_anomalies(df: pd.DataFrame, z_threshold: float = 2.0) -> pd.DataFrame:
    """
    Identify unusual readings using clinical flags and statistical outlier detection.

    Args:
        df:           Classified DataFrame (must have 'status' column).
        z_threshold:  Z-score threshold for statistical outlier detection (default: 2.0).

    Returns:
        DataFrame listing all anomalous readings with reasons.
    """
    anomalies = []

    for patient_id, group in df.groupby("patient_id"):
        mean = group["blood_sugar_mg_dl"].mean()
        std = group["blood_sugar_mg_dl"].std()

        for _, row in group.iterrows():
            reasons = []
            value = row["blood_sugar_mg_dl"]

            # Clinical flag
            if row["status"] in ABNORMAL_STATUSES:
                reasons.append(f"Clinical threshold: {row['status']}")

            # Statistical outlier
            if std > 0 and abs(value - mean) > z_threshold * std:
                z_score = (value - mean) / std
                reasons.append(f"Statistical outlier (z={z_score:.2f})")

            if reasons:
                anomalies.append({
                    "patient_id":  patient_id,
                    "timestamp":   row["timestamp"],
                    "value_mg_dl": value,
                    "type":        row.get("measurement_type", ""),
                    "status":      row["status"],
                    "reasons":     "; ".join(reasons),
                    "notes":       row.get("notes", ""),
                })

    return pd.DataFrame(anomalies) if anomalies else pd.DataFrame(
        columns=["patient_id", "timestamp", "value_mg_dl", "type",
                 "status", "reasons", "notes"]
    )
