"""
main.py
-------
Entry point for the Blood Sugar Analyser.

Usage:
    python main.py [csv_path] [plot_output_path]

Defaults:
    csv_path         : data/blood_sugar.csv
    plot_output_path : docs/blood_sugar_report.png

DISCLAIMER: Educational model only. Not for real clinical decisions.
"""

import sys
import os

# Allow running from project root
sys.path.insert(0, os.path.dirname(__file__))

from src.loader import load_csv
from src.analyser import apply_classifications, compute_metrics, find_anomalies
from src.reporter import print_report
from src.plotter import generate_plot


def run(csv_path: str = "data/blood_sugar.csv",
        plot_path: str = "docs/blood_sugar_report.png") -> dict:
    """
    Execute the full analysis pipeline.

    Args:
        csv_path:  Path to the input CSV file.
        plot_path: Output path for the summary plot.

    Returns:
        Dictionary with keys 'df', 'metrics', 'anomalies' for programmatic use.
    """
    print("\nBlood Sugar Analyser — starting...\n")

    # 1. Load and validate
    df = load_csv(csv_path)
    print(f"[INFO] Loaded {len(df)} readings for "
          f"{df['patient_id'].nunique()} patient(s).")

    # 2. Classify each reading
    df = apply_classifications(df)

    # 3. Compute per-patient metrics
    metrics = compute_metrics(df)

    # 4. Detect anomalies
    anomalies = find_anomalies(df)

    # 5. Print report
    print_report(metrics, anomalies)

    # 6. Generate and save plot
    os.makedirs(os.path.dirname(plot_path), exist_ok=True)
    generate_plot(df, plot_path)

    print("\nAnalysis complete.\n")
    return {"df": df, "metrics": metrics, "anomalies": anomalies}


if __name__ == "__main__":
    csv_file  = sys.argv[1] if len(sys.argv) > 1 else "data/blood_sugar.csv"
    plot_file = sys.argv[2] if len(sys.argv) > 2 else "docs/blood_sugar_report.png"
    run(csv_file, plot_file)
